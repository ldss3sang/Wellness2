import React, { Component } from "react";
import "./App.css";
import { Router,Link } from "react-router-dom";
import NavbarMain from "./components/Navbar";
import Home1 from "./pages/Home1"
import Tour1 from "./pages/Tour1";
import Tour2 from "./pages/Tour2";

export default class App extends Component {
  render() {
    return (
      <div className="App">
        <NavbarMain />
        <div>
        <Link to="/">Home</Link>
        <Link to="/tour1">Tour1</Link>
        <Link to="/tour2">Tour</Link>
      </div>
      <Router>
        <Home1 path="/" />
        <Tour1 path="tour1" />
        <Tour2 path="tour2" />
        </Router>
        
      </div>
    );
    }
}
