import React from "react";
import "../App.css";
const Home = () => (
  <div>
    <main className="home-page" id="home">
      <section className="wrapped-page">
        <div className="item-start">
          <h1>Well Bing Fitness</h1>
          <h1>Happyness travel</h1>
        </div>
      </section>
    </main>
  </div>
);

export default Home;